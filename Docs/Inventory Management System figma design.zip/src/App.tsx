import { useState, useMemo } from "react";
import { Dashboard } from "./components/Dashboard";
import { InventoryTable } from "./components/InventoryTable";
import { ProductDialog } from "./components/ProductDialog";
import { Dues } from "./components/Dues";
import { AppSidebar } from "./components/AppSidebar";
import {
  SidebarProvider,
  SidebarInset,
  SidebarTrigger,
} from "./components/ui/sidebar";
import { Separator } from "./components/ui/separator";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbPage,
} from "./components/ui/breadcrumb";
import { toast, Toaster } from "sonner@2.0.3";
import { generateMockSales } from "./data/mockSales";
import { generateMockCustomers } from "./data/mockCustomers";
import { generateMockSuppliers } from "./data/mockSuppliers";
import type {
  Product,
  InventoryStats,
  Customer,
} from "./types/inventory";

// Mock initial data
const initialProducts: Product[] = [
  {
    id: "1",
    name: "Wireless Mouse",
    sku: "WM-001",
    category: "Electronics",
    quantity: 45,
    minStock: 10,
    price: 29.99,
    supplier: "Tech Supplies Inc",
    lastRestocked: "2025-10-15",
    description: "Ergonomic wireless mouse with USB receiver",
  },
  {
    id: "2",
    name: "Office Chair",
    sku: "OC-102",
    category: "Furniture",
    quantity: 8,
    minStock: 5,
    price: 199.99,
    supplier: "Furniture World",
    lastRestocked: "2025-10-10",
    description: "Adjustable ergonomic office chair",
  },
  {
    id: "3",
    name: "USB-C Cable",
    sku: "UC-250",
    category: "Electronics",
    quantity: 3,
    minStock: 15,
    price: 12.99,
    supplier: "Cable Co",
    lastRestocked: "2025-09-28",
    description: "6ft USB-C charging cable",
  },
  {
    id: "4",
    name: "Notebook A4",
    sku: "NB-450",
    category: "Stationery",
    quantity: 120,
    minStock: 30,
    price: 4.99,
    supplier: "Paper Plus",
    lastRestocked: "2025-10-20",
    description: "Ruled notebook with 200 pages",
  },
  {
    id: "5",
    name: "Standing Desk",
    sku: "SD-300",
    category: "Furniture",
    quantity: 0,
    minStock: 3,
    price: 499.99,
    supplier: "Furniture World",
    lastRestocked: "2025-09-15",
    description: "Electric height-adjustable standing desk",
  },
  {
    id: "6",
    name: "Mechanical Keyboard",
    sku: "KB-600",
    category: "Electronics",
    quantity: 25,
    minStock: 8,
    price: 89.99,
    supplier: "Tech Supplies Inc",
    lastRestocked: "2025-10-18",
    description: "RGB mechanical keyboard with blue switches",
  },
  {
    id: "7",
    name: "Printer Paper",
    sku: "PP-800",
    category: "Stationery",
    quantity: 5,
    minStock: 20,
    price: 24.99,
    supplier: "Paper Plus",
    lastRestocked: "2025-10-05",
    description: "500 sheets of A4 printer paper",
  },
  {
    id: "8",
    name: "Monitor Stand",
    sku: "MS-150",
    category: "Furniture",
    quantity: 15,
    minStock: 5,
    price: 39.99,
    supplier: "Furniture World",
    lastRestocked: "2025-10-22",
    description: "Adjustable monitor stand with storage",
  },
];

const categories = [
  "Electronics",
  "Furniture",
  "Stationery",
  "Office Supplies",
];

export default function App() {
  const [products, setProducts] =
    useState<Product[]>(initialProducts);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<
    Product | undefined
  >();
  const [activeTab, setActiveTab] = useState("dashboard");

  // Generate mock data (memoized to avoid regenerating on each render)
  const salesData = useMemo(() => generateMockSales(), []);
  const [customers, setCustomers] = useState(() =>
    generateMockCustomers(),
  );
  const suppliers = useMemo(() => generateMockSuppliers(), []);

  // Calculate stats
  const stats: InventoryStats = {
    totalProducts: products.length,
    lowStock: products.filter(
      (p) => p.quantity > 0 && p.quantity <= p.minStock,
    ).length,
    outOfStock: products.filter((p) => p.quantity === 0).length,
    totalValue: products.reduce(
      (sum, p) => sum + p.price * p.quantity,
      0,
    ),
    totalDues: customers.reduce(
      (sum, c) => sum + c.dueAmount,
      0,
    ),
    totalDuesPersons: customers.filter((c) => c.dueAmount > 0)
      .length,
    totalSuppliers: suppliers.filter(
      (s) => s.status === "active",
    ).length,
  };

  const handleAddProduct = () => {
    setEditingProduct(undefined);
    setDialogOpen(true);
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setDialogOpen(true);
  };

  const handleSaveProduct = (
    productData: Omit<Product, "id"> & { id?: string },
  ) => {
    if (productData.id) {
      // Update existing product
      setProducts(
        products.map((p) =>
          p.id === productData.id
            ? { ...(productData as Product) }
            : p,
        ),
      );
      toast.success("Product updated successfully");
    } else {
      // Add new product
      const newProduct: Product = {
        ...productData,
        id: Date.now().toString(),
        lastRestocked: new Date().toISOString(),
      };
      setProducts([...products, newProduct]);
      toast.success("Product added successfully");
    }
  };

  const handleDeleteProduct = (id: string) => {
    if (
      confirm("Are you sure you want to delete this product?")
    ) {
      setProducts(products.filter((p) => p.id !== id));
      toast.success("Product deleted successfully");
    }
  };

  const handleUpdateCustomer = (
    customerId: string,
    updatedCustomer: Partial<Customer>,
  ) => {
    setCustomers(
      customers.map((c) =>
        c.id === customerId ? { ...c, ...updatedCustomer } : c,
      ),
    );
    toast.success("Payment recorded successfully");
  };

  const getPageTitle = () => {
    const titles: Record<string, string> = {
      dashboard: "Dashboard",
      inventory: "Inventory",
      dues: "Dues",
      billing: "Billing",
      "profit-loss": "Profit & Loss",
      reports: "Reports",
      suppliers: "Suppliers",
      settings: "Settings",
      account: "Account",
    };
    return titles[activeTab] || "Dashboard";
  };

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return (
          <Dashboard
            products={products}
            stats={stats}
            salesData={salesData}
          />
        );
      case "inventory":
        return (
          <InventoryTable
            products={products}
            categories={categories}
            onAddProduct={handleAddProduct}
            onEditProduct={handleEditProduct}
            onDeleteProduct={handleDeleteProduct}
          />
        );
      case "dues":
        return (
          <Dues
            customers={customers}
            onUpdateCustomer={handleUpdateCustomer}
          />
        );
      case "billing":
      case "profit-loss":
      case "reports":
      case "suppliers":
      case "settings":
      case "account":
        return (
          <div className="flex items-center justify-center h-[calc(100vh-200px)]">
            <div className="text-center">
              <h2 className="text-2xl text-gray-400 mb-2">
                {getPageTitle()}
              </h2>
              <p className="text-gray-500">
                This section is under development
              </p>
            </div>
          </div>
        );
      default:
        return (
          <Dashboard
            products={products}
            stats={stats}
            salesData={salesData}
          />
        );
    }
  };

  return (
    <SidebarProvider defaultOpen={true}>
      <Toaster position="top-right" />
      <AppSidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />
      <SidebarInset>
        {/* Header */}
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          <SidebarTrigger className="-ml-1" />
          <Separator
            orientation="vertical"
            className="mr-2 h-4"
          />
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbPage>
                  {getPageTitle()}
                </BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </header>

        {/* Main Content */}
        <div className="flex flex-1 flex-col gap-4 p-4">
          {renderContent()}
        </div>
      </SidebarInset>

      {/* Product Dialog */}
      <ProductDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        product={editingProduct}
        categories={categories}
        onSave={handleSaveProduct}
      />
    </SidebarProvider>
  );
}