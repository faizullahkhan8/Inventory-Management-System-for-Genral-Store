export interface Product {
  id: string;
  name: string;
  sku: string;
  category: string;
  quantity: number;
  minStock: number;
  price: number;
  supplier: string;
  lastRestocked: string;
  description?: string;
  costPrice?: number;
}

export interface Category {
  id: string;
  name: string;
  count: number;
}

export interface InventoryStats {
  totalProducts: number;
  lowStock: number;
  outOfStock: number;
  totalValue: number;
  totalDues: number;
  totalDuesPersons: number;
  totalSuppliers: number;
}

export interface SalesData {
  id: string;
  productId: string;
  quantity: number;
  salePrice: number;
  costPrice: number;
  date: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  cnic?: string;
  address?: string;
  totalPurchases: number;
  totalPaid: number;
  dueAmount: number;
  lastPurchaseDate: string;
  pendingBills: number;
  status: "overdue" | "pending" | "cleared";
  transactions?: Transaction[];
}

export interface Transaction {
  id: string;
  customerId: string;
  date: string;
  type: "credit_sale" | "payment";
  amount: number;
  remainingDue: number;
  billId?: string;
  paymentMethod?: "cash" | "bank" | "easypaisa" | "jazzcash";
  notes?: string;
}

export interface Supplier {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  productsSupplied: number;
  totalOrders: number;
  lastOrderDate: string;
  status: "active" | "inactive";
}

export type ProfitPeriod = "daily" | "weekly" | "monthly" | "annually";
