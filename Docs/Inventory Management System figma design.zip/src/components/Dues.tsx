import { useState, useMemo } from "react";
import { format } from "date-fns";
import { Search, Filter, Download, Eye, AlertCircle, DollarSign, Users } from "lucide-react";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { DuesDetailsDrawer } from "./DuesDetailsDrawer";
import { ReceivePaymentDialog } from "./ReceivePaymentDialog";
import type { Customer } from "../types/inventory";

interface DuesProps {
  customers: Customer[];
  onUpdateCustomer: (customerId: string, updatedCustomer: Partial<Customer>) => void;
}

export function Dues({ customers, onUpdateCustomer }: DuesProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [detailsDrawerOpen, setDetailsDrawerOpen] = useState(false);
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);

  // Filter customers
  const filteredCustomers = useMemo(() => {
    return customers.filter(customer => {
      // Search filter
      const searchLower = searchQuery.toLowerCase();
      const matchesSearch = 
        customer.name.toLowerCase().includes(searchLower) ||
        customer.phone.includes(searchLower) ||
        customer.id.toLowerCase().includes(searchLower) ||
        customer.email.toLowerCase().includes(searchLower);

      // Status filter
      const matchesStatus = 
        statusFilter === "all" ||
        customer.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [customers, searchQuery, statusFilter]);

  // Calculate summary statistics
  const summaryStats = useMemo(() => {
    const customersWithDues = customers.filter(c => c.dueAmount > 0);
    const totalOutstanding = customers.reduce((sum, c) => sum + c.dueAmount, 0);
    const highestDueCustomer = customers.reduce((max, c) => 
      c.dueAmount > max.dueAmount ? c : max
    , customers[0]);

    return {
      totalCustomersWithDues: customersWithDues.length,
      totalOutstanding,
      highestDueCustomer,
    };
  }, [customers]);

  const handleViewDetails = (customer: Customer) => {
    setSelectedCustomer(customer);
    setDetailsDrawerOpen(true);
  };

  const handleReceivePaymentClick = (customer: Customer) => {
    setSelectedCustomer(customer);
    setPaymentDialogOpen(true);
  };

  const handleReceivePayment = (customerId: string, amount: number, paymentMethod: string, notes: string) => {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;

    const newDueAmount = Math.max(0, customer.dueAmount - amount);
    const newTotalPaid = customer.totalPaid + amount;
    
    // Determine new status
    let newStatus: "overdue" | "pending" | "cleared" = "cleared";
    if (newDueAmount > 0) {
      const daysSinceLastPurchase = Math.floor(
        (new Date().getTime() - new Date(customer.lastPurchaseDate).getTime()) / (1000 * 60 * 60 * 24)
      );
      newStatus = daysSinceLastPurchase > 15 ? "overdue" : "pending";
    }

    // Create new transaction
    const newTransaction = {
      id: `txn-${customerId}-payment-${Date.now()}`,
      customerId,
      date: new Date().toISOString().split('T')[0],
      type: "payment" as const,
      amount,
      remainingDue: newDueAmount,
      paymentMethod: paymentMethod as "cash" | "bank" | "easypaisa" | "jazzcash",
      notes: notes || undefined,
    };

    // Update customer
    onUpdateCustomer(customerId, {
      dueAmount: newDueAmount,
      totalPaid: newTotalPaid,
      status: newStatus,
      pendingBills: newDueAmount === 0 ? 0 : customer.pendingBills,
      transactions: [...(customer.transactions || []), newTransaction],
    });

    // Update selected customer if it's open
    if (selectedCustomer?.id === customerId) {
      setSelectedCustomer({
        ...customer,
        dueAmount: newDueAmount,
        totalPaid: newTotalPaid,
        status: newStatus,
        pendingBills: newDueAmount === 0 ? 0 : customer.pendingBills,
        transactions: [...(customer.transactions || []), newTransaction],
      });
    }
  };

  const handleGeneratePDF = () => {
    // Placeholder for PDF generation
    alert("PDF generation feature coming soon!");
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "overdue":
        return "destructive";
      case "pending":
        return "default";
      case "cleared":
        return "secondary";
      default:
        return "default";
    }
  };

  const getStatusLabel = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Customers with Dues</p>
              <p className="text-2xl">{summaryStats.totalCustomersWithDues}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Outstanding</p>
              <p className="text-2xl">${summaryStats.totalOutstanding.toFixed(2)}</p>
            </div>
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Highest Due</p>
              <p className="text-xl">{summaryStats.highestDueCustomer?.name}</p>
              <p className="text-sm text-red-600 font-medium">
                ${summaryStats.highestDueCustomer?.dueAmount.toFixed(2)}
              </p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <AlertCircle className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Main Content Card */}
      <Card>
        <div className="p-6">
          {/* Header with Search and Filters */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl">Customer Outstanding Dues</h2>
              <p className="text-sm text-muted-foreground">
                Manage and track customer payment dues
              </p>
            </div>
            <Button onClick={handleGeneratePDF} variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Generate PDF
            </Button>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name, phone, or ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <Filter className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="overdue">Overdue</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="cleared">Cleared</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Customers Table */}
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Customer Name</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Last Transaction</TableHead>
                  <TableHead className="text-right">Due Amount</TableHead>
                  <TableHead className="text-center">Pending Bills</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCustomers.length > 0 ? (
                  filteredCustomers.map((customer) => (
                    <TableRow key={customer.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{customer.name}</p>
                          <p className="text-sm text-muted-foreground">{customer.email}</p>
                        </div>
                      </TableCell>
                      <TableCell>{customer.phone}</TableCell>
                      <TableCell>
                        {format(new Date(customer.lastPurchaseDate), "MMM dd, yyyy")}
                      </TableCell>
                      <TableCell className="text-right">
                        <span className={customer.dueAmount > 0 ? "text-red-600 font-medium" : "text-green-600"}>
                          ${customer.dueAmount.toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell className="text-center">{customer.pendingBills}</TableCell>
                      <TableCell className="text-center">
                        <Badge variant={getStatusBadgeVariant(customer.status)}>
                          {getStatusLabel(customer.status)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewDetails(customer)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          {customer.dueAmount > 0 && (
                            <Button
                              variant="default"
                              size="sm"
                              onClick={() => handleReceivePaymentClick(customer)}
                            >
                              Receive Payment
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No customers found matching your criteria
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </Card>

      {/* Customer Details Drawer */}
      <DuesDetailsDrawer
        open={detailsDrawerOpen}
        onOpenChange={setDetailsDrawerOpen}
        customer={selectedCustomer}
        onReceivePayment={handleReceivePaymentClick}
      />

      {/* Receive Payment Dialog */}
      <ReceivePaymentDialog
        open={paymentDialogOpen}
        onOpenChange={setPaymentDialogOpen}
        customer={selectedCustomer}
        onSubmit={handleReceivePayment}
      />
    </div>
  );
}
