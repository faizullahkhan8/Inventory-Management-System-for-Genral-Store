import { useState } from "react";
import { Card } from "./ui/card";
import { Tabs, TabsList, TabsTrigger } from "./ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import type { ProfitPeriod, SalesData } from "../types/inventory";

interface ProfitChartProps {
  salesData: SalesData[];
}

export function ProfitChart({ salesData }: ProfitChartProps) {
  const [period, setPeriod] = useState<ProfitPeriod>("daily");

  // Generate chart data based on period
  const getChartData = () => {
    const now = new Date();
    
    if (period === "daily") {
      // Last 7 days
      const days = [];
      for (let i = 6; i >= 0; i--) {
        const date = new Date(now);
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        
        const daySales = salesData.filter(sale => 
          sale.date.startsWith(dateStr)
        );
        
        const revenue = daySales.reduce((sum, sale) => sum + (sale.salePrice * sale.quantity), 0);
        const cost = daySales.reduce((sum, sale) => sum + (sale.costPrice * sale.quantity), 0);
        const profit = revenue - cost;
        
        days.push({
          name: date.toLocaleDateString('en-US', { weekday: 'short' }),
          revenue,
          cost,
          profit,
        });
      }
      return days;
    }
    
    if (period === "weekly") {
      // Last 8 weeks
      const weeks = [];
      for (let i = 7; i >= 0; i--) {
        const weekStart = new Date(now);
        weekStart.setDate(weekStart.getDate() - (i * 7));
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekEnd.getDate() + 6);
        
        const weekSales = salesData.filter(sale => {
          const saleDate = new Date(sale.date);
          return saleDate >= weekStart && saleDate <= weekEnd;
        });
        
        const revenue = weekSales.reduce((sum, sale) => sum + (sale.salePrice * sale.quantity), 0);
        const cost = weekSales.reduce((sum, sale) => sum + (sale.costPrice * sale.quantity), 0);
        const profit = revenue - cost;
        
        weeks.push({
          name: `Week ${8 - i}`,
          revenue,
          cost,
          profit,
        });
      }
      return weeks;
    }
    
    if (period === "monthly") {
      // Last 12 months
      const months = [];
      for (let i = 11; i >= 0; i--) {
        const monthDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const monthStr = monthDate.toISOString().slice(0, 7); // YYYY-MM
        
        const monthSales = salesData.filter(sale => 
          sale.date.startsWith(monthStr)
        );
        
        const revenue = monthSales.reduce((sum, sale) => sum + (sale.salePrice * sale.quantity), 0);
        const cost = monthSales.reduce((sum, sale) => sum + (sale.costPrice * sale.quantity), 0);
        const profit = revenue - cost;
        
        months.push({
          name: monthDate.toLocaleDateString('en-US', { month: 'short' }),
          revenue,
          cost,
          profit,
        });
      }
      return months;
    }
    
    // Annually - Last 5 years
    const years = [];
    for (let i = 4; i >= 0; i--) {
      const year = now.getFullYear() - i;
      const yearStr = year.toString();
      
      const yearSales = salesData.filter(sale => 
        sale.date.startsWith(yearStr)
      );
      
      const revenue = yearSales.reduce((sum, sale) => sum + (sale.salePrice * sale.quantity), 0);
      const cost = yearSales.reduce((sum, sale) => sum + (sale.costPrice * sale.quantity), 0);
      const profit = revenue - cost;
      
      years.push({
        name: year.toString(),
        revenue,
        cost,
        profit,
      });
    }
    return years;
  };

  const chartData = getChartData();
  const totalProfit = chartData.reduce((sum, item) => sum + item.profit, 0);
  const totalRevenue = chartData.reduce((sum, item) => sum + item.revenue, 0);
  const profitMargin = totalRevenue > 0 ? ((totalProfit / totalRevenue) * 100).toFixed(1) : 0;

  return (
    <Card className="p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h3>Profit Analysis</h3>
          <p className="text-sm text-gray-500 mt-1">
            Total Profit: <span className="text-green-600">${totalProfit.toLocaleString()}</span> 
            {' '}• Margin: <span className="text-blue-600">{profitMargin}%</span>
          </p>
        </div>
        <Tabs value={period} onValueChange={(value) => setPeriod(value as ProfitPeriod)}>
          <TabsList>
            <TabsTrigger value="daily">Daily</TabsTrigger>
            <TabsTrigger value="weekly">Weekly</TabsTrigger>
            <TabsTrigger value="monthly">Monthly</TabsTrigger>
            <TabsTrigger value="annually">Annually</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>
      
      <ResponsiveContainer width="100%" height={350}>
        <BarChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip 
            formatter={(value: number) => `$${value.toLocaleString()}`}
            contentStyle={{ backgroundColor: 'white', border: '1px solid #e5e7eb' }}
          />
          <Legend />
          <Bar dataKey="revenue" fill="#3b82f6" name="Revenue" />
          <Bar dataKey="cost" fill="#ef4444" name="Cost" />
          <Bar dataKey="profit" fill="#10b981" name="Profit" />
        </BarChart>
      </ResponsiveContainer>
    </Card>
  );
}
