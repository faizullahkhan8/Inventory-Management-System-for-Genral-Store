import { format } from "date-fns";
import { ArrowDownCircle, ArrowUpCircle, CreditCard, Phone, MapPin, IdCard } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "./ui/sheet";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Separator } from "./ui/separator";
import type { Customer, Transaction } from "../types/inventory";

interface DuesDetailsDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  customer: Customer | null;
  onReceivePayment: (customer: Customer) => void;
}

export function DuesDetailsDrawer({
  open,
  onOpenChange,
  customer,
  onReceivePayment,
}: DuesDetailsDrawerProps) {
  if (!customer) return null;

  const getPaymentMethodLabel = (method?: string) => {
    const labels: Record<string, string> = {
      cash: "Cash",
      bank: "Bank Transfer",
      easypaisa: "Easypaisa",
      jazzcash: "JazzCash",
    };
    return method ? labels[method] || method : "-";
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Customer Dues Details</SheetTitle>
          <SheetDescription>
            View transaction history and payment details
          </SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Customer Info */}
          <div className="space-y-3 pb-4 border-b">
            <div>
              <h3 className="text-xl">{customer.name}</h3>
              <p className="text-sm text-muted-foreground">{customer.email}</p>
            </div>
            
            <div className="grid grid-cols-1 gap-2 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Phone className="h-4 w-4" />
                <span>{customer.phone}</span>
              </div>
              {customer.cnic && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <IdCard className="h-4 w-4" />
                  <span>{customer.cnic}</span>
                </div>
              )}
              {customer.address && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  <span>{customer.address}</span>
                </div>
              )}
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-muted/50 rounded-lg p-3">
              <p className="text-xs text-muted-foreground">Total Purchases</p>
              <p className="text-lg font-semibold">${customer.totalPurchases.toFixed(2)}</p>
            </div>
            <div className="bg-muted/50 rounded-lg p-3">
              <p className="text-xs text-muted-foreground">Total Paid</p>
              <p className="text-lg font-semibold text-green-600">${customer.totalPaid.toFixed(2)}</p>
            </div>
            <div className="bg-muted/50 rounded-lg p-3">
              <p className="text-xs text-muted-foreground">Due Amount</p>
              <p className="text-lg font-semibold text-red-600">${customer.dueAmount.toFixed(2)}</p>
            </div>
          </div>

          {/* Receive Payment Button */}
          {customer.dueAmount > 0 && (
            <Button
              onClick={() => onReceivePayment(customer)}
              className="w-full"
              size="lg"
            >
              <CreditCard className="mr-2 h-4 w-4" />
              Receive Payment
            </Button>
          )}

          <Separator />

          {/* Transaction History */}
          <div>
            <h4 className="mb-4">Transaction History</h4>
            
            {customer.transactions && customer.transactions.length > 0 ? (
              <div className="space-y-3">
                {customer.transactions.map((transaction) => (
                  <div
                    key={transaction.id}
                    className="flex items-start justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex gap-3">
                      <div className={`mt-0.5 ${transaction.type === "credit_sale" ? "text-red-500" : "text-green-500"}`}>
                        {transaction.type === "credit_sale" ? (
                          <ArrowDownCircle className="h-5 w-5" />
                        ) : (
                          <ArrowUpCircle className="h-5 w-5" />
                        )}
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium">
                            {transaction.type === "credit_sale" ? "Credit Sale" : "Payment Received"}
                          </p>
                          {transaction.billId && (
                            <Badge variant="outline" className="text-xs">
                              {transaction.billId}
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {format(new Date(transaction.date), "MMM dd, yyyy")}
                        </p>
                        {transaction.paymentMethod && (
                          <p className="text-xs text-muted-foreground">
                            via {getPaymentMethodLabel(transaction.paymentMethod)}
                          </p>
                        )}
                        {transaction.notes && (
                          <p className="text-xs text-muted-foreground italic">
                            {transaction.notes}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-semibold ${transaction.type === "credit_sale" ? "text-red-600" : "text-green-600"}`}>
                        {transaction.type === "credit_sale" ? "+" : "-"}${transaction.amount.toFixed(2)}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Due: ${transaction.remainingDue.toFixed(2)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">
                No transactions found
              </p>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
