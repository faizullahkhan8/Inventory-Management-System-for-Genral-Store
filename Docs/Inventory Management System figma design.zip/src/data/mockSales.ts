import type { SalesData } from "../types/inventory";

// Generate mock sales data for the past year
export function generateMockSales(): SalesData[] {
  const sales: SalesData[] = [];
  const now = new Date();
  
  // Product IDs from the initial products
  const productIds = ["1", "2", "3", "4", "5", "6", "7", "8"];
  
  // Cost prices for products (roughly 60-70% of sale price)
  const costPrices: Record<string, number> = {
    "1": 18.99,  // Wireless Mouse
    "2": 129.99, // Office Chair
    "3": 7.99,   // USB-C Cable
    "4": 2.99,   // Notebook A4
    "5": 324.99, // Standing Desk
    "6": 54.99,  // Mechanical Keyboard
    "7": 15.99,  // Printer Paper
    "8": 24.99,  // Monitor Stand
  };
  
  // Generate sales for past 365 days
  for (let daysAgo = 365; daysAgo >= 0; daysAgo--) {
    const date = new Date(now);
    date.setDate(date.getDate() - daysAgo);
    const dateStr = date.toISOString().split('T')[0];
    
    // Random number of sales per day (0-8)
    const numSales = Math.floor(Math.random() * 9);
    
    for (let i = 0; i < numSales; i++) {
      const productId = productIds[Math.floor(Math.random() * productIds.length)];
      const quantity = Math.floor(Math.random() * 5) + 1;
      
      // Sale prices based on product ID
      const salePrices: Record<string, number> = {
        "1": 29.99,
        "2": 199.99,
        "3": 12.99,
        "4": 4.99,
        "5": 499.99,
        "6": 89.99,
        "7": 24.99,
        "8": 39.99,
      };
      
      sales.push({
        id: `sale-${daysAgo}-${i}`,
        productId,
        quantity,
        salePrice: salePrices[productId] || 10,
        costPrice: costPrices[productId] || 5,
        date: dateStr,
      });
    }
  }
  
  return sales;
}
