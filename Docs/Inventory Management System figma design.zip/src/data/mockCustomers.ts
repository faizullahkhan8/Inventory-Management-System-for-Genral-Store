import type { Customer, Transaction } from "../types/inventory";

// Helper function to generate transactions for a customer
function generateTransactions(customerId: string, dueAmount: number, totalPurchases: number, totalPaid: number): Transaction[] {
  const transactions: Transaction[] = [];
  let remainingDue = 0;
  
  // Generate credit sales
  const numSales = Math.floor(Math.random() * 3) + 2; // 2-4 sales
  const avgSaleAmount = totalPurchases / numSales;
  
  for (let i = 0; i < numSales; i++) {
    const amount = Math.round((avgSaleAmount + (Math.random() - 0.5) * avgSaleAmount * 0.5) * 100) / 100;
    remainingDue += amount;
    const daysAgo = Math.floor(Math.random() * 30) + (numSales - i) * 3;
    const date = new Date();
    date.setDate(date.getDate() - daysAgo);
    
    transactions.push({
      id: `txn-${customerId}-${i}`,
      customerId,
      date: date.toISOString().split('T')[0],
      type: "credit_sale",
      amount,
      remainingDue: Math.round(remainingDue * 100) / 100,
      billId: `BILL-${customerId.toUpperCase()}-${String(i + 1).padStart(3, '0')}`,
    });
  }
  
  // Generate payments
  if (totalPaid > 0) {
    const numPayments = Math.floor(Math.random() * 2) + 1; // 1-2 payments
    const avgPaymentAmount = totalPaid / numPayments;
    
    for (let i = 0; i < numPayments; i++) {
      const amount = Math.round((avgPaymentAmount + (Math.random() - 0.5) * avgPaymentAmount * 0.3) * 100) / 100;
      remainingDue -= amount;
      const daysAgo = Math.floor(Math.random() * 25) + 2;
      const date = new Date();
      date.setDate(date.getDate() - daysAgo);
      
      const paymentMethods: ("cash" | "bank" | "easypaisa" | "jazzcash")[] = ["cash", "bank", "easypaisa", "jazzcash"];
      
      transactions.push({
        id: `txn-${customerId}-payment-${i}`,
        customerId,
        date: date.toISOString().split('T')[0],
        type: "payment",
        amount,
        remainingDue: Math.round(remainingDue * 100) / 100,
        paymentMethod: paymentMethods[Math.floor(Math.random() * paymentMethods.length)],
        notes: i === 0 ? "Partial payment" : undefined,
      });
    }
  }
  
  // Sort by date ascending
  transactions.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  
  return transactions;
}

// Generate mock customer data with dues
export function generateMockCustomers(): Customer[] {
  const customers: Customer[] = [
    {
      id: "c1",
      name: "Sarah Johnson",
      email: "sarah.johnson@email.com",
      phone: "+1 (555) 123-4567",
      cnic: "12345-6789012-3",
      address: "123 Main Street, New York, NY 10001",
      totalPurchases: 1250.00,
      totalPaid: 1250.00,
      dueAmount: 0,
      lastPurchaseDate: "2025-10-25",
      pendingBills: 0,
      status: "cleared",
      transactions: [],
    },
    {
      id: "c2",
      name: "Michael Chen",
      email: "m.chen@company.com",
      phone: "+1 (555) 234-5678",
      cnic: "23456-7890123-4",
      address: "456 Oak Avenue, Los Angeles, CA 90001",
      totalPurchases: 3450.50,
      totalPaid: 2800.00,
      dueAmount: 650.50,
      lastPurchaseDate: "2025-10-28",
      pendingBills: 2,
      status: "pending",
      transactions: [],
    },
    {
      id: "c3",
      name: "Emily Rodriguez",
      email: "emily.r@business.net",
      phone: "+1 (555) 345-6789",
      cnic: "34567-8901234-5",
      address: "789 Pine Road, Chicago, IL 60601",
      totalPurchases: 890.75,
      totalPaid: 890.75,
      dueAmount: 0,
      lastPurchaseDate: "2025-10-20",
      pendingBills: 0,
      status: "cleared",
      transactions: [],
    },
    {
      id: "c4",
      name: "James Wilson",
      email: "jwilson@enterprise.com",
      phone: "+1 (555) 456-7890",
      cnic: "45678-9012345-6",
      address: "321 Elm Street, Houston, TX 77001",
      totalPurchases: 5200.00,
      totalPaid: 4000.00,
      dueAmount: 1200.00,
      lastPurchaseDate: "2025-10-02",
      pendingBills: 3,
      status: "overdue",
      transactions: [],
    },
    {
      id: "c5",
      name: "Amanda Lee",
      email: "amanda.lee@startup.io",
      phone: "+1 (555) 567-8901",
      cnic: "56789-0123456-7",
      address: "654 Maple Drive, Phoenix, AZ 85001",
      totalPurchases: 2100.25,
      totalPaid: 1650.00,
      dueAmount: 450.25,
      lastPurchaseDate: "2025-10-26",
      pendingBills: 1,
      status: "pending",
      transactions: [],
    },
    {
      id: "c6",
      name: "Robert Brown",
      email: "rbrown@tech.com",
      phone: "+1 (555) 678-9012",
      cnic: "67890-1234567-8",
      address: "987 Cedar Lane, Philadelphia, PA 19101",
      totalPurchases: 1580.00,
      totalPaid: 1580.00,
      dueAmount: 0,
      lastPurchaseDate: "2025-10-22",
      pendingBills: 0,
      status: "cleared",
      transactions: [],
    },
    {
      id: "c7",
      name: "Jessica Martinez",
      email: "jessica.m@design.co",
      phone: "+1 (555) 789-0123",
      cnic: "78901-2345678-9",
      address: "147 Birch Street, San Antonio, TX 78201",
      totalPurchases: 4300.80,
      totalPaid: 3500.00,
      dueAmount: 800.80,
      lastPurchaseDate: "2025-10-29",
      pendingBills: 1,
      status: "pending",
      transactions: [],
    },
    {
      id: "c8",
      name: "David Kim",
      email: "dkim@solutions.com",
      phone: "+1 (555) 890-1234",
      cnic: "89012-3456789-0",
      address: "258 Walnut Avenue, San Diego, CA 92101",
      totalPurchases: 975.50,
      totalPaid: 675.50,
      dueAmount: 300.00,
      lastPurchaseDate: "2025-10-05",
      pendingBills: 2,
      status: "overdue",
      transactions: [],
    },
    {
      id: "c9",
      name: "Lisa Anderson",
      email: "l.anderson@corp.net",
      phone: "+1 (555) 901-2345",
      cnic: "90123-4567890-1",
      address: "369 Ash Boulevard, Dallas, TX 75201",
      totalPurchases: 1820.00,
      totalPaid: 1820.00,
      dueAmount: 0,
      lastPurchaseDate: "2025-10-19",
      pendingBills: 0,
      status: "cleared",
      transactions: [],
    },
    {
      id: "c10",
      name: "Christopher Taylor",
      email: "ctaylor@innovate.com",
      phone: "+1 (555) 012-3456",
      cnic: "01234-5678901-2",
      address: "741 Spruce Street, Seattle, WA 98101",
      totalPurchases: 3650.00,
      totalPaid: 2950.00,
      dueAmount: 700.00,
      lastPurchaseDate: "2025-10-28",
      pendingBills: 2,
      status: "pending",
      transactions: [],
    },
  ];

  // Generate transactions for each customer
  customers.forEach(customer => {
    customer.transactions = generateTransactions(
      customer.id,
      customer.dueAmount,
      customer.totalPurchases,
      customer.totalPaid
    );
  });

  return customers;
}
