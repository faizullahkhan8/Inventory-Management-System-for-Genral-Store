
  # Inventory Management System

  This is a code bundle for Inventory Management System. The original project is available at https://www.figma.com/design/X3JKWMy9g3VbNFa0eVfJbw/Inventory-Management-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  